@API(owner = "Baubles", apiVersion = baubles.common.Baubles.VERSION, provides = "Baubles|API")
package baubles.api;

import cpw.mods.fml.common.API;

