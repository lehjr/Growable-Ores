package universalelectricity.api.core.grid.electric;

/**
 * Created by Darkguardsman on 7/29/2014.
 */
public interface IResistance
{
    /**
     * Resistance in Ohms
     */
    public double getResistance();
}
