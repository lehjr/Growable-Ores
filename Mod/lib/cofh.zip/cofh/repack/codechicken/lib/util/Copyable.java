package cofh.repack.codechicken.lib.util;

public interface Copyable<T> {

	public T copy();
}
