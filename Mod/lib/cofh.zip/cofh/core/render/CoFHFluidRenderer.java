package cofh.core.render;

public class CoFHFluidRenderer {

	public CoFHFluidRenderer() {

		// TODO Auto-generated constructor stub
		// render a list of icons (flowing/non + base; color overlay)
		// check for specialized icons (getIcons(register, String name); getIcons(register, name, int color, int color2))
	}

}
