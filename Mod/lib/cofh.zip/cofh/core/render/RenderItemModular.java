package cofh.core.render;

import net.minecraft.item.ItemStack;
import net.minecraftforge.client.IItemRenderer;

public class RenderItemModular implements IItemRenderer {

	@Override
	public boolean handleRenderType(ItemStack item, ItemRenderType type) {

		if (ItemRenderRegistry.validItem(item)) {
			return ItemRenderRegistry.getItemRenderer(item).handleRenderType(item, type);
		}
		return false;
	}

	@Override
	public boolean shouldUseRenderHelper(ItemRenderType type, ItemStack item, ItemRendererHelper helper) {

		if (ItemRenderRegistry.validItem(item)) {
			return ItemRenderRegistry.getItemRenderer(item).shouldUseRenderHelper(type, item, helper);
		}
		return false;
	}

	@Override
	public void renderItem(ItemRenderType type, ItemStack item, Object... data) {

		if (ItemRenderRegistry.validItem(item)) {
			ItemRenderRegistry.getItemRenderer(item).renderItem(type, item, data);
		}
	}

}
