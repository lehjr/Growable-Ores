package powercrystals.minefactoryreloaded.api;

import net.minecraft.entity.EntityLivingBase;

public interface ILiquidDrinkHandler
{
	public void onDrink(EntityLivingBase player);
}
